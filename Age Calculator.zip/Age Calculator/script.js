// // const months = [ 31,28,31,30,31,30,31,30,31,30,31,30,];


// // function ageCalculate(){
// //     let today = new Date(document.getElementById("date-input").value);
// //     let birthMonth,birthDate,birthYear;




// //     let birthDetails = {
// //         Date:inputDate.getDate(),
// //         month:inputDate.getMonth()+1,
// //         year:inputDate.getFullYear()

// //     }

// //     let CurrentYear = today.getFullYear();
    
// //     let CurrentMonth = today.getMonth()+1;
// //     let CurrentDate = today.getDate();




// //     leapCheacker(CurrentYear);

// //     if( birthDetails.Year > CurrentYear ||
// //             (birthDetails.month > CurrentMonth &&
// //         birthDetails.year > CurrentYear)||
// //         (birthDetails.date > CurrentDate &&
// //             birthDetails.Date.month == CurrentMonth && birthDetails.Date.year ==
// //              CurrentYear)
            
// //     )
// //     {
// //             alert("Not Born Yet");
// //             return;
// //     }
// //     birthYear = CurrentYear -   birthDetails.year;
// //     if(CurrentMonth >= birthDetails.month)
// //         {
// //             birthMonth = CurrentMonth - birthDetails.month;
// //         }

// //         else{
// //             birthYear--;
// //             birthMonth = 12 + currentMonth - birthDetails.month;
// //         }
        
// //     if(CurrentDate >= birthDetails.date)
// //     {
// //         birthDate = CurrentDate - birthDetails.date;
// //     }

// //     else{
// //         birthMonth--;
        
// //         let days = months[currentMonth - 2];
// //         birthDate = days + CurrentDate - birthDetails.date; 
         
// //         if(birthmonth < 0){
// //             birthMonth = 11;
// //             birthYear--;
// //         }   
// //     }

// //     console.log(birthYear,birthMonth,birthDate);

// // }


// // function leapCheacker(Year){
// //     if(year % 4 == 0 || (year == 0 && year
// //          % 400 == 0)){
// //             months[1] =29;

// //          }
// //          else{
// //             months[1] = 28;

// //          }

// //          console.log(year , months[1]);

// // }

// const months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Days in each month (adjusted February to 28 days for default)

// function ageCalculate() {
//     let today = new Date(document.getElementById("date-input").value);
//     let birthMonth, birthDate, birthYear;

//     let birthDetails = {
//         Date: today.getDate(),
//         month: today.getMonth() + 1,
//         year: today.getFullYear()
//     };

//     let currentYear = (new Date()).getFullYear();
//     let currentMonth = (new Date()).getMonth() + 1;
//     let currentDate = (new Date()).getDate();

//     leapChecker(currentYear); // Check for leap year

//     // Check if birthdate is in the future
//     if (birthDetails.year > currentYear ||
//         (birthDetails.month > currentMonth && birthDetails.year >= currentYear) ||
//         (birthDetails.Date > currentDate && birthDetails.month === currentMonth && birthDetails.year === currentYear)) {
//         alert("Not Born Yet");
//         displayResult("-","-","-");
//         return;
//     }

//     // Calculate age in years
//     birthYear = currentYear - birthDetails.year;
    
//     // Calculate age in months
//     if (currentMonth >= birthDetails.month) {
//         birthMonth = currentMonth - birthDetails.month;
//     } else {
//         birthYear--; // Adjust year if current month is less than birth month
//         birthMonth = 12 + currentMonth - birthDetails.month;
//     }

//     // Calculate age in days
//     if (currentDate >= birthDetails.Date) {
//         birthDate = currentDate - birthDetails.Date;
//     } else {
//         birthMonth--; // Adjust month if current date is less than birth date
//         let daysInPreviousMonth = months[(currentMonth + 11) % 12]; // Get days in previous month
//         birthDate = daysInPreviousMonth + currentDate - birthDetails.Date;
        
//         if (birthMonth < 0) {
//             birthMonth = 11; // Adjust month to December if it goes below January
//             birthYear--; // Subtract one year if month went below January
//         }
//     }

//     console.log("Age:", birthYear, "years", birthMonth, "months", birthDate, "days");
// }

// function leapChecker(year) {
//     if ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) {
//         months[1] = 29; // Adjust February to 29 days for leap year
//     } else {
//         months[1] = 28; // Set February back to 28 days for non-leap year
//     }
//     displayResult(birthDate,birthMonth,birthYear);
// }



// // function displayResult(bdate,bmonth,byear){
// //     document.getElementById("Years").textContent = bYear;
// //     document.getElementById("Month").textContent = bMonth;
// //     document.getElementById("Date").textContent = bdate;


// // }


// function displayResult(bdate, bmonth, byear) {
//     document.getElementById("Years").textContent = byear;
//     document.getElementById("Month").textContent = bmonth;
//     document.getElementById("Date").textContent = bdate;
// }


const months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Days in each month (adjusted February to 28 days for default)

function ageCalculate() {
    let today = new Date(document.getElementById("date-input").value);
    let birthMonth, birthDate, birthYear;

    let birthDetails = {
        Date: today.getDate(),
        month: today.getMonth() + 1,
        year: today.getFullYear()
    };

    let currentYear = (new Date()).getFullYear();
    let currentMonth = (new Date()).getMonth() + 1;
    let currentDate = (new Date()).getDate();

    leapChecker(currentYear); // Check for leap year

    // Check if birthdate is in the future
    if (birthDetails.year > currentYear ||
        (birthDetails.month > currentMonth && birthDetails.year >= currentYear) ||
        (birthDetails.Date > currentDate && birthDetails.month === currentMonth && birthDetails.year === currentYear)) {
        alert("Not Born Yet");
        displayResult("-", "-", "-");
        return;
    }

    // Calculate age in years
    birthYear = currentYear - birthDetails.year;
    
    // Calculate age in months
    if (currentMonth >= birthDetails.month) {
        birthMonth = currentMonth - birthDetails.month;
    } else {
        birthYear--; // Adjust year if current month is less than birth month
        birthMonth = 12 + currentMonth - birthDetails.month;
    }

    // Calculate age in days
    if (currentDate >= birthDetails.Date) {
        birthDate = currentDate - birthDetails.Date;
    } else {
        birthMonth--; // Adjust month if current date is less than birth date
        let daysInPreviousMonth = months[(currentMonth + 11) % 12]; // Get days in previous month
        birthDate = daysInPreviousMonth + currentDate - birthDetails.Date;
        
        if (birthMonth < 0) {
            birthMonth = 11; // Adjust month to December if it goes below January
            birthYear--; // Subtract one year if month went below January
        }
    }

    console.log("Age:", birthYear, "years", birthMonth, "months", birthDate, "days");
    displayResult(birthDate, birthMonth, birthYear);
}

function leapChecker(year) {
    if ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) {
        months[1] = 29; // Adjust February to 29 days for leap year
    } else {
        months[1] = 28; // Set February back to 28 days for non-leap year
    }
}

function displayResult(bdate, bmonth, byear) {
    document.getElementById("Years").textContent = byear;
    document.getElementById("Month").textContent = bmonth;
    document.getElementById("Days").textContent = bdate;
}
